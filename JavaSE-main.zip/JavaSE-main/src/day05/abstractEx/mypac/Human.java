package day05.abstractEx.mypac;

// 추상클래스 
public abstract class Human {
	
	// 일반메소드
	public void say() {
		System.out.println("말을 해요!");
	}
	
	// 추상메소드
	public abstract void dance();

}
