package day05.interfaceEx.mypac;

public interface Weapon {
	final static String NAME ="Ak-47";
	
	public void attack();
	public void attackSky();
	
}
