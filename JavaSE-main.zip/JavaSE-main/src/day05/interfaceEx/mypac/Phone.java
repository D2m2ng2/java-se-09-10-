package day05.interfaceEx.mypac;

public interface Phone {
	
	public void call();		// 정의 되지 않은 추상메소드
	public void receive(); 	// 정의 되지 않은 추상메소드

}
