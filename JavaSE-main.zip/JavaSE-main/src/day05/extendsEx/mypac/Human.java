package day05.extendsEx.mypac;


public class Human {
	
	public void say() {
		System.out.println("말을 해요!");
	}

}
