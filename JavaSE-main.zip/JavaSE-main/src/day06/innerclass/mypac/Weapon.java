package day06.innerclass.mypac;

public interface Weapon {
	
	public void attack();

}
