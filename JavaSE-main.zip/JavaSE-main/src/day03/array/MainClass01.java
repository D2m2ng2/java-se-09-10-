package day03.array;

/*
 * 배열
 * 	- 하나의 변수에 여러값을 저장하는데 쓰이는 자료구조
 */

public class MainClass01 {
	public static void main(String[] args) {
		// 정수를 10개 담을수 있는 배열 객체 생성하기
		int[] nums = new int[10];
		// 실수를 10개 담을수 있는 배열 객체 생성하기
		double[] nums2 = new double[10];
		// 문자열(String) 10개를 담을수 있는 배열 객체 생성하기.
		String[] str = new String[10];
		
		// str 배열의 0번째 인덱스에 저장된 내용 출력해보기
		System.out.println(nums[0]);
		
		
		
	}

}
