package day03.basic;

/*
 * 따라 작성해보세요~ for 문 연습하기
 * *****
 * *****
 * *****
 * *****
 */

public class MainClass01 {
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		System.out.println("");
	}
		
}