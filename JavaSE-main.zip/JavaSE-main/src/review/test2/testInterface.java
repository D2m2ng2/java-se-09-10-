package review.test2;

public interface testInterface {
	
	public void testInterMethod();

}
