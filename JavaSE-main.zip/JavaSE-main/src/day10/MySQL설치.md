### 1. 버추얼 박스 설치

1-1 구글 버추얼박스 검색 버전 6.1 (!7.0 X 안됩니다!!!)   
https://www.virtualbox.org/wiki/Downloads   
1-2 다운로드 설치!!   
 windows hosts 클릭 다운로드!   
 
### 2. Vagrant 설치

2-1 구글 Vagrant 검색
https://www.vagrantup.com/    
2-2 다운로드 설치 -> Next 디폴트 설치 -> 재부팅


### 3. Cmder 설치

3-1 구글 Cmder 검색  
https://cmder.app/   
3-2 download full 클릭 다운로드   
3-3 압축파일이라서 압축해제 후 실행가능


### 4. Vagrantfile 만들기 (Vagrantfile 존재시 생략 5번으로 가세요)
4-1 구글 vagrant cloud 사이트 검색
https://app.vagrantup.com/   
4-2 필요한 이미지 검색  
4-3 cmder 실행   
4-4 vagrant file 만들기
vagrant init 이미지명 


### 5. Vagrantfile 존재시 
5-1 파일탐색기 실행 원하는경로에 새폴더 만들기
예) C:\작업폴더명\vagrant\server1

5-2 cmder 만든폴더 접속
```
cd C:\작업폴더명\vagrant\server1
```

### 6. vagrant 이미지 설치 및 실행
6-1 vagrant 설치 및 실행
```
vagrant up
```

### 7. vagrant 접속
7-1 vagrant 접속
```
vagrant ssh
```

### 8. HeidiSQL 설치
8-1 HeidiSQL 설치   
https://www.heidisql.com/download.php?download=installer   

8-2 Installer, 32/64 bit combined  클릭! 다운로드!  














