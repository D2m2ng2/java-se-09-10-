package day07.accessmodifier.mypac;

public class HandPhone {
	
	public static void main(String[] args) {
		Phone p = new Phone();
//		p.call();
	}

}
