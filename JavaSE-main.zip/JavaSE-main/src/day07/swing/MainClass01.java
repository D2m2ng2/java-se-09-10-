package day07.swing;

import day07.swing.mypac.MyFrame01;

/*
 * 
 * GUI(Graphic User Interface) 환경 만들기
 * 
 
 * 
 */


public class MainClass01 {

	public static void main(String[] args) {
		
		new MyFrame01();
		
	}
}
