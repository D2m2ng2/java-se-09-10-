### Vagrant 명령어 정리!
- vagrant 이미지 파일 생성
```
vagrant init 이미지명
```
- vagrant 이미지 설치 및 시작
```
vagrant up
```
- vagrant 접속
```
vagrant ssh
```
- vagrant 종료
```
vagrant halt
```
- vagrant 이미지 삭제
```
vagrant destroy
```

