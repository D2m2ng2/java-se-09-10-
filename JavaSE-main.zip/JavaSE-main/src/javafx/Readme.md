### Java FX


- JavaFX SDK  다운로드
https://gluonhq.com/products/javafx/


-  이클립스 javafx 플러그인 e(fx)clipse 설치
```
[help] -> [Eclipse Marketplace] -> "JAVAFX" 검색 -> e(fx)clipse 설치 -> 이클립스 재시작
```

- SceneBuilder 다운로드
https://gluonhq.com/products/scene-builder/

- SceneBuilder 이클립스 연동
```
[Windows] -> [Preferences] -> [JavaFX] -> [SceneBuilder executable] -> SceneBuilder.exe 경로저장
```